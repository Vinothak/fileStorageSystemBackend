const express=require('express')
const router=express.Router()
const bodyparser=require('body-parser');
const bcrypt=require('bcryptjs');
const Users= require('../models/users')

router.post('/login', (req,res)=>{
  
    console.log(req.body);
  
    const {email,password}=req.body;
 
     Users.findOne({email:email})
     .then(user=>{
 
         if(user){
            bcrypt.compare(password,user.password,(err,isMatch)=>{
                if(err) throw err;
        
                if(isMatch){
                    var obj={
                        username:user._id,
                        msg:"Authenticated user"
                    }
                    res.send(obj);
                }else{
                    res.send("Password do not match");
                }
            })
          }else{
              res.send("Email id is not valid");
          }
        })
          .catch(err=>console.log(err));
        
            })

///Regsitration of users            

 router.post('/register', (req,res)=>{
  
   console.log(req.body);
  
   const {name,email,password}=req.body;

 
    Users.findOne({email:email})
    .then(user=>{

        if(user){
             res.send( res.send({status:"Failed",
             message:"User already exists with the mail id"})
             );
        }else{
          const newUser=new Users({
              name,
              email,
              password
          });

          console.log(newUser)
          bcrypt.genSalt(10,(err,salt)=> 
             bcrypt.hash(newUser.password,salt, (err,hash)=>{
        if(err) 
        {
            console.log("Error is: ",err);
        }
        newUser.password=hash;
             newUser.save()
             .then(user=>{
                 res.send({status:"Success",
                 message:"You are registered successfully"});
             })
             .catch(err =>console.log(err));
          }))
        }
})
});

module.exports= router