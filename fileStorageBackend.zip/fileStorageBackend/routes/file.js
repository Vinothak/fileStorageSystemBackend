const express=require('express')
const router=express.Router()
const Users= require('../models/users')
const File= require('../models/file')
const {join}= require('path'); 
const Formidable = require('formidable')
const bluebird = require('bluebird')
const fs = bluebird.promisifyAll(require('fs'))


router.get('/download/:filepath',(req,res)=>{
	res.download(join(__dirname, 'dist','uploads',`${req.params.filepath}`), function (err) {
		console.log(err);
	});
})



//View files
router.get('/get-files/:userId', async (req,res)=>{
	console.log('Get file request');
	
		 if(req.params.userId=="5f611c1ed35a882ef802ce64"){
			 try{
				const dbresponse=await File.find();
				console.log(dbresponse);
				res.send(dbresponse)
			 }catch(err){
					res.json({message:err})
					res.send({
						Status:"failed",
						Message:"0 Records fetched"
					})
				 }
		 }else{
			try{
				const dbresponse=await File.find({user : req.params.userId});
				console.log(dbresponse);
				res.send(dbresponse)
			 }catch(err){
					res.json({message:err})
					res.send({
						Status:"failed",
						Message:"0 Records fetched"
					})
				 }
		 }
 })
 //Add file  
 function checkAcceptedExtensions (file) {
	const type = file.type.split('/').pop()
	console.log(type);
	const accepted = ['jpeg', 'jpg', 'png', 'gif', 'pdf','plain']
	if (accepted.indexOf(type) == -1) {
		return false
	}
	return true
}

 router.post('/add-files/:user', (req,res)=>{

	var user=req.params.user
	console.log("user is",user);
  var nameOfTheFile=null;
    let form = Formidable.IncomingForm()
	const uploadsFolder = join(__dirname, 'dist', 'uploads')
	form.multiples = true
	form.uploadDir = uploadsFolder
	form.maxFileSize = 50 * 1024 * 1024 // 50 MB
	const folderCreationResult =  checkCreateUploadsFolder(uploadsFolder)
	if (!folderCreationResult) {
		return res.json({ok: false, msg: "The uploads folder couldn't be created"})
	}

	form.parse(req, async (err, fields, files) => {
		let myUploadedFiles = []
		if (err) {
			console.log('Error parsing the incoming form')
			return res.json({ok: false, msg: 'Error passing the incoming form'})
		}
		// If we are sending only one file:
		if (!files.files.length) {
			const file = files.files
	
			if (!checkAcceptedExtensions(file)) {
				console.log('The received file is not a valid type')
				return res.json({ok: false, msg: 'The sent file is not a valid type'})
			}
			const fileName = encodeURIComponent(file.name.replace(/&. *;+/g, '-'))
			myUploadedFiles.push(fileName)
			try {
				await fs.renameAsync(file.path, join(uploadsFolder, fileName))
			} catch (e) {
				console.log('Error uploading the file')
				try { await fs.unlinkAsync(file.path) } catch (e) {}
				return res.json({ok: false, msg: 'Error uploading the file'})
			}
		} else {
			for(let i = 0; i < files.files.length; i++) {
				const file = files.files[i]
				if (!checkAcceptedExtensions(file)) {
					console.log('The received file is not a valid type')
					return res.json({ok: false, msg: 'The sent file is not a valid type'})
				}
				const fileName = encodeURIComponent(file.name.replace(/&. *;+/g, '-'))
				myUploadedFiles.push(fileName)
				nameOfTheFile=fileName
				try {
					await fs.renameAsync(file.path, join(uploadsFolder, fileName))
				} catch (e) {
					console.log('Error uploading the file')
					try { await fs.unlinkAsync(file.path) } catch (e) {}
					return res.json({ok: false, msg: 'Error uploading the file'})
				}
			}
		}
		
        console.log(nameOfTheFile);
		const newFile=new File({
			path:myUploadedFiles[0],
			user:user
		})
				
		newFile.save()
		.then(file=>{
		 res.send({status:"Success",
			   message:"Inserted data"});
		   }).catch(err=>console.log(err));
	
	})
 
  });



  
  async function checkCreateUploadsFolder (uploadsFolder) {
	try {
		await fs.statAsync(uploadsFolder)
	} catch (e) {
		if (e && e.code == 'ENOENT') {
			console.log('The uploads folder doesn\'t exist, creating a new one...')
			try {
				await fs.mkdirAsync(uploadsFolder)
			} catch (err) {
				console.log('Error creating the uploads folder 1')
				return false
			}
		} else {
			console.log('Error creating the uploads folder 2')
			return false
		}
	}
	return true
}

module.exports= router