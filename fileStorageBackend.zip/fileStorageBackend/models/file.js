const mongoose=require('mongoose');

const FileSchema= mongoose.Schema({
 user:{
        type:String,
        required:true
 },
 path:{
    type:String,
    required:true
 },
 date:{
   type:Date,
   default:Date.now
}

});

module.exports = mongoose.model('File',FileSchema)