const express=require('express')
const PORT = process.env.PORT || 5000
const mongoose=require('mongoose')
const bodyParser=require('body-parser');
var cors = require('cors')
var app = express()

app.use(cors())


app.use(bodyParser.urlencoded())

app.use(bodyParser.json())
 app.use(function(req,res,next){
   res.header('Access-Control-Allow-Origin',
   "https://vibrant-heyrovsky-6eb7fb.netlify.app");
   res.header('Access-Control-Allow-Origin',
   "http://localhost:3000");
   res.set('Access-Control-Allow-Credentials', 'true')
 		res.header('Access-Control-Allow-Methods','GET,PUT,POST,DELETE,PATCH');
 		res.header('Access-Control-Allow-Headers','Content-Type');
 		next();
 });



const fileRoute=require('./routes/file.js');
const login=require('./routes/user.js');
app.use('/file',fileRoute)
app.use('/users',login)

var url=`mongodb+srv://vinothak:aaCeM2dkATYlx2xL@cluster0-cf7ns.mongodb.net/sample?retryWrites=true&w=majority`
mongoose.connect(url,{useNewUrlParser:true,
    useUnifiedTopology: true},()=>{
    console.log('mongo db connected');
})
// mongoose.connect(process.env.DB_CONNECTION,{useNewUrlParser:true,useUnifiedTopology: true},()=>{
//   console.log('mongo db connected');
// })

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  console.log("Our db is connected");
});

app.listen(PORT,function(){
    console.log('server started on',PORT);
})
